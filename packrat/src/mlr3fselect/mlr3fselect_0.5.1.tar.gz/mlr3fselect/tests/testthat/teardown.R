pmap(list(loggers, thresholds), function(l, threshold) l$set_threshold(threshold))
