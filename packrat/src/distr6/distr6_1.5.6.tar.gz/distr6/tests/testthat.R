library(testthat)
library(distr6)

test_check("distr6")
