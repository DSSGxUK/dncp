library(testthat)
library(set6)

test_check("set6")
