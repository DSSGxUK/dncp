#' @name set6-deprecated
#' @rdname set6-deprecated
#' @title Deprecated set6 Functions and Classes
#' @description The functions listed below are deprecated and will be defunct in
#'   the near future. When possible, alternative functions with similar
#'   functionality are also mentioned. Help pages for deprecated functions are
#'   available at \code{help("-deprecated")}.
#' @keywords internal
NULL
