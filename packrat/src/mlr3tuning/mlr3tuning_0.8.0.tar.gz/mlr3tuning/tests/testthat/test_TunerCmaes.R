test_that("TunerCmaes", {
  test_tuner("cmaes")
})
