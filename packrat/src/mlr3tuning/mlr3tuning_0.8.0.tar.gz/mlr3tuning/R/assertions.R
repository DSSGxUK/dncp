assert_tuner = function(tuner) {
  assert_r6(tuner, "Tuner")
}
