library(testthat)
library(R62S3)

test_check("R62S3")

