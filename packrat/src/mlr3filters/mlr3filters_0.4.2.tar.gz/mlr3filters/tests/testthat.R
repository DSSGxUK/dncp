library(testthat)
library(mlr3filters)

test_check("mlr3filters")
