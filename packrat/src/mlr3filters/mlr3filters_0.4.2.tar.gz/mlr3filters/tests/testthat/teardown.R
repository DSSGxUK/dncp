options(old_opts)
lg$set_threshold(old_threshold)
