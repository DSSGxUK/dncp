# context("mlr_task_generators_friedman1")
#
# test_that("mlr_task_generators_friedman1", {
#   gen = mlr_task_generators$get("friedman1dens")
#   task = gen$generate(100)
#   expect_task_density(task)
# })
