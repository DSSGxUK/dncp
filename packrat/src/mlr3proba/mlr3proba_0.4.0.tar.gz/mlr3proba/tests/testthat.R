library(testthat)
library(checkmate) # for more expect_*() functions
library(mlr3proba)

test_check("mlr3proba")
