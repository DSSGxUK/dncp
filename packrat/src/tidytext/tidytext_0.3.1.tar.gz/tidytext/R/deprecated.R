#' @rdname deprecated-se
#' @param ... All arguments for non-deprecated functions
#' @export
bind_tf_idf_ <- function(...) {
  .Deprecated("bind_tf_idf")
  bind_tf_idf(...)
}

#' @rdname deprecated-se
#' @param ... All arguments for non-deprecated functions
#' @export
cast_sparse_ <- function(...) {
  .Deprecated("cast_sparse")
  cast_sparse(...)
}

#' @rdname deprecated-se
#' @param ... All arguments for non-deprecated functions
#' @export
cast_tdm_ <- function(...) {
  .Deprecated("cast_tdm")
  cast_tdm(...)
}

#' @rdname deprecated-se
#' @param ... All arguments for non-deprecated functions
#' @export
cast_dtm_ <- function(...) {
  .Deprecated("cast_dtm")
  cast_dtm(...)
}

#' @rdname deprecated-se
#' @param ... All arguments for non-deprecated functions
#' @export
cast_dfm_ <- function(...) {
  .Deprecated("cast_dfm")
  cast_dfm(...)
}

#' @rdname deprecated-se
#' @param ... All arguments for non-deprecated functions
#' @export
unnest_tokens_ <- function(...) {
  .Deprecated("unnest_tokens")
  unnest_tokens(...)
}

